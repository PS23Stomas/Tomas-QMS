<?php
/**
 * Prisijungimo puslapis - autentifikacija pagal vardą ir slaptažodį
 *
 * Funkcionalumas:
 * - Automatinis prisijungimas per „prisiminti mane" (remember_token) slapuką
 * - Sesijos tikrinimas ir nukreipimas jei jau prisijungta
 * - POST autentifikacija: vardo ir slaptažodžio patikra
 * - Slaptažodžio validacija: ≥8 simbolių ir ≥1 skaičius
 */

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'None'
]);
ini_set('session.gc_maxlifetime', 1800);
session_start();

// Duomenų bazės prisijungimas per DATABASE_URL aplinkos kintamąjį
$database_url = getenv('DATABASE_URL');
$parsed = parse_url($database_url);
$dsn = "pgsql:host={$parsed['host']};port=" . ($parsed['port'] ?? 5432) . ";dbname=" . ltrim($parsed['path'], '/');
$pdo = new PDO($dsn, $parsed['user'], $parsed['pass'], [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);

$klaida = '';

/**
 * Normalizuoja rolės pavadinimą — production DB gali turėti "admin"/"user",
 * o sistema tikrina "administratorius"/"vartotojas". Konvertuojame į vieningą formatą.
 */
function normalizuotiRole(string $role): string {
    return match($role) {
        'admin'          => 'administratorius',
        'user'           => 'vartotojas',
        'administrator'  => 'administratorius',
        default          => $role,
    };
}

// CSRF žetono generavimas (inline, nes login.php nenaudoja config.php)
if (empty($_SESSION['_csrf_token'])) {
    $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
}
$_csrf_token = $_SESSION['_csrf_token'];

// Automatinio prisijungimo tikrinimas per „prisiminti mane" slapuką (remember_token)
if (!isset($_SESSION['vartotojas_id']) && isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    $hashed_token = hash('sha256', $token);
    
    try {
        $stmt = $pdo->prepare("
            SELECT v.id, v.vardas, v.pavarde, v.role 
            FROM remember_tokens rt
            JOIN vartotojai v ON rt.vartotojas_id = v.id
            WHERE rt.token = ? AND rt.expires_at > CURRENT_TIMESTAMP
        ");
        $stmt->execute([$hashed_token]);
        $user = $stmt->fetch();
        
        if ($user) {
            session_regenerate_id(true);
            $_SESSION['vartotojas_id'] = $user['id'];
            $_SESSION['vardas'] = $user['vardas'];
            $_SESSION['pavarde'] = $user['pavarde'];
            $normRole = normalizuotiRole($user['role'] ?? '');
            $_SESSION['role'] = $normRole;
            $_SESSION['paskutine_veikla'] = time();
            if ($normRole !== ($user['role'] ?? '')) {
                $pdo->prepare("UPDATE vartotojai SET role = ? WHERE id = ?")->execute([$normRole, $user['id']]);
            }
            
        } else {
            setcookie('remember_token', '', [
                'expires' => time() - 3600,
                'path' => '/',
                'secure' => true,
                'httponly' => true,
                'samesite' => 'None'
            ]);
        }
    } catch (Exception $e) {
    }
}

// Jei vartotojas jau prisijungęs ir tai GET užklausa - rodome nukreipimo nuorodą formoje (ne 302)
$jau_prisijunges = isset($_SESSION['vartotojas_id']);

// POST užklausos apdorojimas: prisijungimo formos duomenų tikrinimas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pateiktas_csrf = $_POST['_csrf'] ?? '';
    if (!$_csrf_token || !hash_equals($_csrf_token, $pateiktas_csrf)) {
        http_response_code(403);
        die('CSRF patikrinimas nepavyko. Atnaujinkite puslapį ir bandykite dar kartą.');
    }
    $vardas = trim($_POST['vardas'] ?? '');
    $slaptazodis = $_POST['slaptazodis'] ?? '';

    if ($vardas && $slaptazodis) {
        // Serverio pusės slaptažodžio validacija
        if (strlen($slaptazodis) < 8) {
            $klaida = "Slaptažodis turi būti bent 8 simbolių ilgio.";
        } elseif (!preg_match('/\d/', $slaptazodis)) {
            $klaida = "Slaptažodyje turi būti bent vienas skaičius.";
        } else {
            // Vartotojo paieška pagal vardą arba el. paštą (jei yra @ — ieškoma el. paštu)
            if (str_contains($vardas, '@')) {
                $stmt = $pdo->prepare("SELECT id, vardas, pavarde, slaptazodis, role FROM vartotojai WHERE el_pastas = :vardas LIMIT 1");
            } else {
                $stmt = $pdo->prepare("SELECT id, vardas, pavarde, slaptazodis, role FROM vartotojai WHERE vardas = :vardas ORDER BY (role IN ('administratorius','admin')) DESC, id ASC LIMIT 1");
            }
            $stmt->execute(['vardas' => $vardas]);
            $naudotojas = $stmt->fetch();

            // Slaptažodžio tikrinimas su password_verify (bcrypt)
            if ($naudotojas && password_verify($slaptazodis, $naudotojas['slaptazodis'])) {
                // Sėkmingas prisijungimas: sesijos kintamųjų nustatymas
                session_regenerate_id(true);
                
                $_SESSION['vartotojas_id'] = $naudotojas['id'];
                $_SESSION['vardas'] = $naudotojas['vardas'];
                $_SESSION['pavarde'] = $naudotojas['pavarde'];
                $normRole = normalizuotiRole($naudotojas['role'] ?? '');
                $_SESSION['role'] = $normRole;
                $_SESSION['paskutine_veikla'] = time();
                if ($normRole !== ($naudotojas['role'] ?? '')) {
                    $pdo->prepare("UPDATE vartotojai SET role = ? WHERE id = ?")->execute([$normRole, $naudotojas['id']]);
                }
                
                // „Prisiminti mane" slapuko kūrimas (30 dienų galiojimas)
                if (isset($_POST['remember']) && $_POST['remember'] == '1') {
                    $token = bin2hex(random_bytes(32));
                    $expires = time() + (30 * 24 * 60 * 60);
                    
                    $stmt_token = $pdo->prepare("INSERT INTO remember_tokens 
                        (vartotojas_id, token, expires_at) 
                        VALUES (?, ?, TO_TIMESTAMP(?))");
                    $stmt_token->execute([$naudotojas['id'], hash('sha256', $token), $expires]);
                    
                    setcookie('remember_token', $token, [
                        'expires' => $expires,
                        'path' => '/',
                        'secure' => true,
                        'httponly' => true,
                        'samesite' => 'None'
                    ]);
                }
                
                http_response_code(200);
                echo '<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0;url=/moduliai.php"></head><body><p>Nukreipiama...</p><script>window.location.replace("/moduliai.php")</script></body></html>';
                exit;
            } else {
                $klaida = "Neteisingi prisijungimo duomenys.";
            }
        }
    } else {
        $klaida = "Visi laukai yra privalomi.";
    }
}
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#4c596d">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>Prisijungimas - Tomo-QMS</title>
    <link rel="shortcut icon" type="image/png" href="/favicon-32.png?v=2">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png?v=2">
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"></noscript>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #4c596d 0%, #1e293b 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .login-card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 2.5rem;
            width: 100%;
            max-width: 440px;
        }
        .login-card h2 {
            font-weight: 700;
            color: #333;
            margin-bottom: 0.5rem;
            text-align: center;
            font-size: 1.5rem;
        }
        .login-subtitle {
            text-align: center;
            color: #888;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-label {
            display: block;
            font-weight: 600;
            color: #555;
            font-size: 0.9rem;
            margin-bottom: 0.4rem;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            font-size: 1rem;
            border: 2px solid #e0e0e0;
            border-radius: 0.5rem;
            font-family: 'Inter', sans-serif;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .form-control:focus {
            outline: none;
            border-color: #736a48;
            box-shadow: 0 0 0 3px rgba(115, 106, 72, 0.2);
        }
        .form-control.is-invalid {
            border-color: #dc2626;
        }
        .field-error {
            color: #dc2626;
            font-size: 0.8rem;
            margin-top: 0.3rem;
            display: none;
        }
        .field-error.visible {
            display: block;
        }
        .remember-row {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1.25rem;
            margin-top: 0.25rem;
        }
        .remember-row input[type="checkbox"] {
            width: 16px;
            height: 16px;
            cursor: pointer;
            accent-color: #a59a6d;
        }
        .remember-row label {
            font-size: 0.9rem;
            color: #555;
            cursor: pointer;
        }
        .btn-login {
            width: 100%;
            padding: 0.85rem;
            font-size: 1.05rem;
            font-weight: 600;
            border: none;
            border-radius: 0.5rem;
            background: linear-gradient(135deg, #a59a6d 0%, #595029 100%);
            color: white;
            cursor: pointer;
            transition: opacity 0.2s, transform 0.1s;
            font-family: 'Inter', sans-serif;
        }
        .btn-login:hover { opacity: 0.9; }
        .btn-login:active { transform: scale(0.98); }
        .alert {
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            font-size: 0.9rem;
        }
        .alert-danger {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        .forgot-link {
            text-align: center;
            margin-top: 1.25rem;
        }
        .forgot-link a {
            color: #a59a6d;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
        }
        .forgot-link a:hover { text-decoration: underline; }
        @media (max-width: 480px) {
            .login-card { padding: 1.5rem; }
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>Tomo_QMS sistema</h2>
        <p class="login-subtitle">Kokybės valdymo sistema</p>
        <?php if ($jau_prisijunges): ?>
            <div data-testid="text-already-logged-in" style="text-align:center;padding:1.5rem 0;">
                <p style="color:#333;margin-bottom:1rem;">Jūs jau esate prisijungęs kaip <strong><?= htmlspecialchars($_SESSION['vardas'] ?? '') ?> <?= htmlspecialchars($_SESSION['pavarde'] ?? '') ?></strong></p>
                <a href="/moduliai.php" class="btn-login" style="display:inline-block;text-decoration:none;text-align:center;padding:0.85rem 2rem;" data-testid="link-go-to-modules">Tęsti į sistemą</a>
            </div>
        <?php else: ?>
        <?php if (isset($_GET['sesija_pasibaige']) && $_GET['sesija_pasibaige'] == '1'): ?>
            <div class="alert alert-warning" data-testid="text-session-expired" style="background:#fff3cd;color:#856404;border:1px solid #ffc107;padding:0.75rem 1rem;border-radius:0.5rem;margin-bottom:1rem;font-size:0.9rem;">
                Jūsų sesija baigėsi dėl neaktyvumo. Prašome prisijungti iš naujo.
            </div>
        <?php endif; ?>
        <?php if ($klaida): ?>
            <div class="alert alert-danger" data-testid="text-login-error"><?= htmlspecialchars($klaida) ?></div>
        <?php endif; ?>
        <form method="POST" action="/login.php" id="loginForm" novalidate>
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_csrf_token) ?>">
            <div class="form-group">
                <label class="form-label" for="vardas">Vardas arba el. paštas</label>
                <input type="text" class="form-control" id="vardas" name="vardas"
                       value="<?= htmlspecialchars($_POST['vardas'] ?? '') ?>" required
                       autocomplete="username"
                       placeholder="Vardas arba el. paštas"
                       data-testid="input-vardas">
            </div>
            <div class="form-group">
                <label class="form-label" for="slaptazodis">Slaptažodis</label>
                <input type="password" class="form-control" id="slaptazodis" name="slaptazodis" required
                       data-testid="input-password">
                <div class="field-error" id="slaptazodisKlaida" data-testid="text-password-error"></div>
            </div>
            <div class="remember-row">
                <input type="checkbox" id="remember" name="remember" value="1" data-testid="checkbox-remember">
                <label for="remember">Prisiminti mane</label>
            </div>
            <button type="submit" class="btn-login" data-testid="button-login">Prisijungti</button>
        </form>
        <div class="forgot-link">
            <a href="/slaptazodis_atstatymas.php" data-testid="link-forgot-password">Pamiršau slaptažodį</a>
        </div>
        <script>
        (function(){
            var v = document.getElementById('vardas');
            var s = document.getElementById('slaptazodis');
            var errEl = document.getElementById('slaptazodisKlaida');
            if (!v || !s) return;

            // Autofill iš localStorage (tik vardas)
            var saved_v = localStorage.getItem('login_vardas') || '';
            if (!v.value && saved_v) v.value = saved_v;

            if (v.value) {
                s.focus();
            } else {
                v.focus();
            }

            // Slaptažodžio laukinis tikrinimas realiuoju laiku
            s.addEventListener('input', function() {
                validatePassword(false);
            });

            document.getElementById('loginForm').addEventListener('submit', function(e) {
                if (!validatePassword(true)) {
                    e.preventDefault();
                    return;
                }
                localStorage.setItem('login_vardas', v.value);
            });

            function validatePassword(showEmpty) {
                var val = s.value;
                if (!val) {
                    if (showEmpty) {
                        showErr('Slaptažodis yra privalomas.');
                        return false;
                    }
                    hideErr();
                    return true;
                }
                if (val.length < 8) {
                    showErr('Slaptažodis turi būti bent 8 simbolių ilgio.');
                    return false;
                }
                if (!/\d/.test(val)) {
                    showErr('Slaptažodyje turi būti bent vienas skaičius.');
                    return false;
                }
                hideErr();
                return true;
            }

            function showErr(msg) {
                s.classList.add('is-invalid');
                errEl.textContent = msg;
                errEl.classList.add('visible');
            }

            function hideErr() {
                s.classList.remove('is-invalid');
                errEl.textContent = '';
                errEl.classList.remove('visible');
            }
        })();
        </script>
        <?php endif; ?>
    </div>
</body>
</html>
