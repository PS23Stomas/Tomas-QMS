<?php
/**
 * Dielektrinių bandymų protokolo PDF generavimas ir išsaugojimas
 *
 * Šis failas atsakingas už dielektrinių bandymų protokolo PDF dokumento sukūrimą.
 * Dielektriniai bandymai — tai elektros patikros, kurių metu tikrinama ar gaminyje
 * esanti izoliacija atlaiko aukštą įtampą (pvz. 3 kV).
 *
 * Kaip veikia:
 * 1. Gauna gaminio ID iš formos arba URL
 * 2. Nuskaito visus bandymų duomenis iš duomenų bazės
 * 3. Sugeneruoja PDF dokumentą naudodamas mPDF biblioteką
 * 4. Išsaugo PDF į duomenų bazę (gaminiai lentelės mt_dielektriniu_pdf laukas)
 * 5. Grąžina PDF naršyklei peržiūrai arba atsisiuntimui
 *
 * Jei gaminio ID nenurodytas — nukreipia į užsakymų sąrašą.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../klases/TomoQMS.php';

requireLogin();

$conn = Database::getConnection();

$gaminio_id = $_POST['gaminio_id'] ?? $_GET['gaminio_id'] ?? null;
$uzsakymo_numeris = $_POST['uzsakymo_numeris'] ?? $_GET['uzsakymo_numeris'] ?? '';
$uzsakovas = $_POST['uzsakovas'] ?? $_GET['uzsakovas'] ?? '';
$gaminio_pavadinimas = $_POST['gaminio_pavadinimas'] ?? $_GET['gaminio_pavadinimas'] ?? '';
$uzsakymo_id = $_POST['uzsakymo_id'] ?? $_GET['uzsakymo_id'] ?? '';
$grupe = $_POST['grupe'] ?? $_GET['grupe'] ?? 'MT';

if (!$gaminio_id) {
    header('Location: /uzsakymai.php');
    exit;
}

$grupes_pavadinimas = 'MT';
$uzsakymo_id_db = 0;
try {
    $stmtGr = $conn->prepare("SELECT gr.pavadinimas, u.id as uzs_id FROM gaminiai g JOIN uzsakymai u ON g.uzsakymo_id = u.id JOIN gaminiu_rusys gr ON u.gaminiu_rusis_id = gr.id WHERE g.id = :gid");
    $stmtGr->execute([':gid' => $gaminio_id]);
    $grRow = $stmtGr->fetch(PDO::FETCH_ASSOC);
    if ($grRow) {
        $grupes_pavadinimas = $grRow['pavadinimas'] ?: 'MT';
        $uzsakymo_id_db = (int)($grRow['uzs_id'] ?? 0);
    }
} catch (PDOException $e) {}

$stmt = $conn->prepare("SELECT id, protokolo_nr, dielektriniai_issaugoti, gaminio_numeris, pavadinimas FROM gaminiai WHERE id=?");
$stmt->execute([$gaminio_id]);
$gaminys = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$gaminys) die("Klaida: gaminys nerastas");
$protokolo_nr = $gaminys['protokolo_nr'] ?? '';
$jau_issaugota = !empty($gaminys['dielektriniai_issaugoti']);
$gaminio_numeris_db = $gaminys['gaminio_numeris'] ?? '';
$gaminio_pavadinimas_db = $gaminys['pavadinimas'] ?? $gaminio_pavadinimas;

$vardas = $_SESSION['vardas'] ?? '';
$pavarde = $_SESSION['pavarde'] ?? '';
$pareigos = "";
$data = date("Y-m-d");

$stmt = $conn->prepare("SELECT * FROM bandymai_prietaisai WHERE gaminys_id=? ORDER BY prietaiso_tipas");
$stmt->execute([$gaminio_id]);
$prietaisai = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $conn->prepare("SELECT * FROM dielektriniai_bandymai WHERE gaminys_id=? AND tipas='vidutines_itampos' ORDER BY eiles_nr");
$stmt->execute([$gaminio_id]);
$vid_itampa = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $conn->prepare("SELECT * FROM dielektriniai_bandymai WHERE gaminys_id=? AND (tipas='mazos_itampos' OR tipas IS NULL) ORDER BY eiles_nr");
$stmt->execute([$gaminio_id]);
$maz_itampa = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $conn->prepare("SELECT * FROM izeminimo_tikrinimas WHERE gaminys_id=? ORDER BY eil_nr");
$stmt->execute([$gaminio_id]);
$izem = $stmt->fetchAll(PDO::FETCH_ASSOC);

$trafo_kiekis = 1;
if (preg_match_all('/(\d+)x(\d+)/', $gaminio_pavadinimas_db ?: $gaminio_pavadinimas, $all_matches, PREG_SET_ORDER)) {
    foreach ($all_matches as $m) {
        if (intval($m[2]) >= 100) {
            $trafo_kiekis = intval($m[1]);
            break;
        }
    }
}

$stmt = $conn->prepare("SELECT * FROM saugikliu_ideklai WHERE gaminio_id = ? AND sekcija = '3.5' ORDER BY pozicijos_numeris ASC");
$stmt->execute([$gaminio_id]);
$mt_saugikliai = $stmt->fetchAll(PDO::FETCH_ASSOC);

$mt_saugikliai_36 = [];
if ($trafo_kiekis >= 2) {
    $stmt = $conn->prepare("SELECT * FROM saugikliu_ideklai WHERE gaminio_id = ? AND sekcija = '3.6' ORDER BY pozicijos_numeris ASC");
    $stmt->execute([$gaminio_id]);
    $mt_saugikliai_36 = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function generuotiSaugikliuHtmlDiel($duomenys, $pozicijos) {
    $saug_map = [];
    foreach ($duomenys as $s) {
        $saug_map[(int)$s['pozicijos_numeris']] = $s;
    }
    $html = '<table class="saugikliu-sub"><tr class="sub-header">';
    foreach ($pozicijos as $p) { $html .= '<td>' . $p . '</td>'; }
    $html .= '</tr><tr>';
    foreach ($pozicijos as $p) {
        $html .= '<td>' . htmlspecialchars($saug_map[$p]['gabaritas'] ?? '') . '</td>';
    }
    $html .= '</tr><tr>';
    foreach ($pozicijos as $p) {
        $html .= '<td>' . htmlspecialchars($saug_map[$p]['nominalas'] ?? '') . '</td>';
    }
    $html .= '</tr></table>';
    return $html;
}

if ($trafo_kiekis == 1) {
    $poz_35 = range(1, 15);
    $label_35 = 'ŠĮ-0,4 sekcijos komplektuojamų saugiklių-lydžiųjų įdėklų gabaritas, nominalas:';
} else {
    $poz_35 = array_merge(range(101, 106), range(301, 304));
    $label_35 = 'Š1-0,4 (ir Š3-0,4 pagal schemą) sekcijos komplektuojamų saugiklių-lydžiųjų įdėklų gabaritas, nominalas:';
}
$saugikliu_html = generuotiSaugikliuHtmlDiel($mt_saugikliai, $poz_35);

$saugikliu_36_html = '';
if ($trafo_kiekis >= 2) {
    $poz_36 = array_merge(range(201, 206), range(401, 404));
    $saugikliu_36_html = generuotiSaugikliuHtmlDiel($mt_saugikliai_36, $poz_36);
}

$parasas_base64 = '';
$vartotojo_id = $_SESSION['vartotojas_id'] ?? 0;
if ($vartotojo_id) {
    $stmt_par = $conn->prepare("SELECT parasas, parasas_tipas, pareigos FROM vartotojai WHERE id = ?");
    $stmt_par->execute([$vartotojo_id]);
    $par_row = $stmt_par->fetch(PDO::FETCH_ASSOC);
    if ($par_row) {
        $pareigos = $par_row['pareigos'] ?? '';
        if (!empty($par_row['parasas'])) {
            $par_mime = $par_row['parasas_tipas'] ?: 'image/jpeg';
            $par_data = $par_row['parasas'];
            if (is_resource($par_data)) $par_data = stream_get_contents($par_data);
            $parasas_base64 = 'data:' . $par_mime . ';base64,' . base64_encode($par_data);
        }
    }
}
if (empty($pareigos)) $pareigos = 'Kokybės inžinierius';

$prietaisai_html = '';
if (!empty($prietaisai)) {
    $i = 1;
    foreach ($prietaisai as $p) {
        $prietaisai_html .= '<tr>
            <td>' . $i++ . '</td>
            <td>' . htmlspecialchars($p['prietaiso_tipas']) . '</td>
            <td>' . htmlspecialchars($p['prietaiso_nr']) . '</td>
            <td>' . htmlspecialchars($p['patikra_data']) . '</td>
            <td>' . htmlspecialchars($p['galioja_iki']) . '</td>
            <td>' . htmlspecialchars($p['sertifikato_nr']) . '</td>
        </tr>';
    }
} else {
    $prietaisai_html = '<tr><td colspan="6">Prietaisai nepriskirti</td></tr>';
}

$vid_itampa_html = '';
if (!empty($vid_itampa)) {
    $i = 1;
    foreach ($vid_itampa as $row) {
        $vid_itampa_html .= '<tr>
            <td>' . $i++ . '</td>
            <td class="text-left">' . htmlspecialchars($row['grandines_pavadinimas'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['grandines_itampa'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['bandymo_schema'] ?? 'L - (kabelio ekranas + P)') . '</td>
            <td>' . htmlspecialchars($row['bandymo_itampa_kV'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['bandymo_trukme'] ?? '') . '</td>
        </tr>';
    }
} elseif (!$jau_issaugota) {
    $t = (stripos($gaminio_pavadinimas, '2x') !== false) ? 2 : 1;
    for ($i = 1; $i <= $t; $i++) {
        $label = ($t == 1) ? 'transformatorių' : "T-$i";
        $vid_itampa_html .= '<tr>
            <td>' . $i . '</td>
            <td class="text-left">Kabeliai į ' . $label . ', Gyslos L1, L2, L3</td>
            <td>10</td>
            <td>L - (kabelio ekranas + PE)</td>
            <td>13</td>
            <td>60</td>
        </tr>';
    }
} else {
    $vid_itampa_html = '<tr><td colspan="6">Duomenys nesuvesti</td></tr>';
}

$maz_itampa_html = '';
if (!empty($maz_itampa)) {
    $i = 1;
    foreach ($maz_itampa as $row) {
        $maz_itampa_html .= '<tr>
            <td>' . $i++ . '</td>
            <td class="text-left">' . htmlspecialchars($row['aprasymas'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['itampa'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['schema1'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['schema2'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['schema3'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['schema4'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['schema5'] ?? '') . '</td>
            <td>' . htmlspecialchars($row['schema6'] ?? '') . '</td>
        </tr>';
    }
} else {
    $maz_itampa_html = '<tr><td colspan="9">Duomenys nesuvesti</td></tr>';
}

$izem_html = '';
if (!empty($izem)) {
    foreach ($izem as $row) {
        $izem_html .= '<tr>
            <td>' . htmlspecialchars($row['eil_nr']) . '</td>
            <td class="text-left">' . htmlspecialchars($row['tasko_pavadinimas']) . '</td>
            <td>' . htmlspecialchars($row['matavimo_tasku_skaicius']) . '</td>
            <td>' . htmlspecialchars($row['varza_ohm']) . '</td>
            <td>' . htmlspecialchars($row['budas']) . '</td>
            <td>' . htmlspecialchars($row['bukle']) . '</td>
        </tr>';
    }
} else {
    $izem_html = '<tr><td colspan="6">Duomenys nesuvesti</td></tr>';
}

$imone = getUzsakymoImone($uzsakymo_id_db);

$html = '
<style>
body {
    font-family: "DejaVu Sans", Arial, sans-serif;
    font-size: 11px;
    line-height: 1.4;
    color: #000;
}
.company-header {
    text-align: center;
    margin-bottom: 12px;
    padding-bottom: 10px;
    border-bottom: 2px solid #000;
}
.company-name { font-size: 15px; margin-bottom: 2px; }
.company-name span { font-weight: 700; }
.company-details { font-size: 10px; color: #333; line-height: 1.5; }
h2 { font-size: 14px; text-align: center; margin: 15px 0 10px 0; text-transform: uppercase; }
h3 { font-size: 12px; margin: 15px 0 6px 0; text-transform: uppercase; font-weight: 700; }
table.data-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 10px;
    margin-bottom: 10px;
}
table.data-table td, table.data-table th {
    border: 1px solid #000;
    padding: 3px 5px;
    vertical-align: middle;
    text-align: center;
}
table.data-table th {
    background: #e9ecef;
    font-weight: 700;
    font-size: 10px;
}
.text-left { text-align: left !important; }
.meta-line { font-size: 11px; margin: 4px 0; }
.isvada { font-size: 11px; font-weight: 600; margin: 8px 0; }
.pastaba { font-size: 10px; font-style: italic; margin: 8px 0; }
.sig-table { width: 100%; margin-top: 25px; }
.sig-table td { vertical-align: bottom; padding: 5px; }
.sig-title { font-weight: 600; }
.sig-name { font-weight: 600; }
.sig-subtitle { font-size: 9px; color: #666; }
.sig-date-label { font-size: 9px; color: #666; }
.sig-label { font-size: 9px; color: #666; }
.saugikliu-sub {
    width: 100%;
    border-collapse: collapse;
    font-size: 10px;
    margin: 0;
}
.saugikliu-sub td {
    border: 1px solid #000;
    padding: 2px 3px;
    text-align: center;
    vertical-align: middle;
}
.saugikliu-sub .sub-header td {
    background: #e9ecef;
    font-weight: 700;
    font-size: 9px;
}
</style>

<div class="company-header">
    <div class="company-name">' . htmlspecialchars($imone['pavadinimas']) . '</div>
    <div class="company-details">
        ' . htmlspecialchars($imone['adresas']) . '<br>
        Tel. ' . htmlspecialchars($imone['telefonas']) . ', Faks. ' . htmlspecialchars($imone['faksas']) . '<br>
        El. paštas: ' . htmlspecialchars($imone['el_pastas']) . ' | Internetas: ' . htmlspecialchars($imone['internetas']) . '
    </div>
</div>

<h2>BANDYMŲ PROTOKOLAS NR. ' . htmlspecialchars($protokolo_nr) . '</h2>

<div class="meta-line"><strong>Užsakymo Nr.:</strong> ' . htmlspecialchars($uzsakymo_numeris) . '</div>
<div class="meta-line"><strong>Užsakovas:</strong> ' . htmlspecialchars($uzsakovas) . '</div>
<div class="meta-line"><strong>Gaminys:</strong> ' . htmlspecialchars($gaminio_pavadinimas_db ?: $gaminio_numeris_db) . '</div>

<h3>Matavimai atlikti prietaisais:</h3>
<table class="data-table">
<thead>
<tr><th>Nr.</th><th>Tipas</th><th>Nr.</th><th>Patikra</th><th>Galioja iki</th><th>Sertifikatas</th></tr>
</thead>
<tbody>' . $prietaisai_html . '</tbody>
</table>

' . ($grupes_pavadinimas === 'MT' ? '
<h3>SAUGIKLIŲ ĮDĖKLAI</h3>
<table class="data-table">
<thead>
<tr><th>Nr.</th><th>Aprašymas</th><th>Gabaritas / Nominalas</th></tr>
</thead>
<tbody>
<tr><td>3.5</td><td class="text-left">' . htmlspecialchars($label_35) . '</td><td style="padding:0;">' . ($saugikliu_html ?: 'Duomenys nesuvesti') . '</td></tr>
' . ($trafo_kiekis >= 2 ? '<tr><td>3.6</td><td class="text-left">Š2-0,4 (ir Š4-0,4 pagal schemą) sekcijos komplektuojamų saugiklių-lydžiųjų įdėklų gabaritas, nominalas:</td><td style="padding:0;">' . ($saugikliu_36_html ?: 'Duomenys nesuvesti') . '</td></tr>' : '') . '
</tbody>
</table>' : '') . '

' . (!empty($vid_itampa) || !$jau_issaugota ? '
<h3>Vidutinės įtampos (6–24 kV) kabelių bandymas</h3>
<table class="data-table">
<thead>
<tr><th>Eil. Nr.</th><th>Bandymo elementų aprašymas</th><th>Un (kV)</th><th>Bandymo schema</th><th>Band. įtampa (kV)</th><th>Trukmė (min)</th></tr>
</thead>
<tbody>' . $vid_itampa_html . '</tbody>
</table>
<div class="isvada">Išvada: 10kV kabeliai bandymus išlaikė, izoliacija gera.</div>' : '') . '

' . (!empty($maz_itampa) || !$jau_issaugota ? '
<h3>0,4kV grandinių bandymas paaukštinta įtampa</h3>
<table class="data-table">
<thead>
<tr><th>Eil. Nr.</th><th>El. grandinių aprašymas</th><th>Grandinių įtampa</th><th>L1-PE</th><th>L2-PE</th><th>L3-PE</th><th>L1-L2</th><th>L2-L3</th><th>L1-L3</th></tr>
</thead>
<tbody>' . $maz_itampa_html . '</tbody>
</table>
<div class="isvada">Išvada: 0,4kV įranga bandymus išlaikė, izoliacija gera.</div>' : '') . '

' . (!empty($izem) || !$jau_issaugota ? '
<h3>Grandinės tarp įžeminimo varžtų ir įžemintinų elementų tikrinimas</h3>
<table class="data-table">
<thead>
<tr><th style="width:8%">Eil. Nr.</th><th style="width:35%">Įžemintinų taškų pavadinimas</th><th style="width:17%">Matavimo taškų skaičius</th><th style="width:18%">Grandinės varža (Ω)</th><th style="width:11%">Būdas</th><th style="width:11%">Būklė</th></tr>
</thead>
<tbody>' . $izem_html . '</tbody>
</table>' : '') . '

<div class="pastaba"><strong>Pastaba:</strong> Matavimai atlikti varžto, skirto įžemiklio (įžeminimo kontūro) prijungimui. Įžeminimo varžos normos ribose. Matavimai atlikti pagal galiojančius standartus ir darbo instrukcijas.</div>

<div class="isvada">Išvada: Gaminys tinka eksploatacijai.</div>

<table class="sig-table">
    <tr>
        <td style="width:33%;text-align:left;">
            <div class="sig-title">' . htmlspecialchars($pareigos) . '</div>
            <div class="sig-name">' . htmlspecialchars($vardas . ' ' . $pavarde) . '</div>
            <div class="sig-subtitle">Pareigos, Vardas, Pavardė</div>
        </td>
        <td style="width:33%;text-align:center;">
            <div style="font-weight:600;">' . htmlspecialchars($data) . '</div>
            <div class="sig-date-label">Data</div>
        </td>
        <td style="width:33%;text-align:center;">
            ' . ($parasas_base64 ? '<img src="' . $parasas_base64 . '" style="max-height:60px;"><br>' : '') . '
            <div class="sig-label">(parašas)/antspaudas</div>
        </td>
    </tr>
</table>';

try {
    $mpdf = new \Mpdf\Mpdf([
        'mode' => 'utf-8',
        'format' => 'A4',
        'orientation' => 'P',
        'margin_left' => 12,
        'margin_right' => 12,
        'margin_top' => 10,
        'margin_bottom' => 10,
        'tempDir' => '/tmp/mpdf',
    ]);

    $mpdf->SetTitle($grupes_pavadinimas . ' Dielektriniai bandymai - ' . $uzsakymo_numeris);
    $mpdf->SetAuthor($imone['pavadinimas']);
    $mpdf->WriteHTML($html);

    $pdf_content = $mpdf->Output('', 'S');

    $failo_pavadinimas = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $uzsakymo_numeris) . '_Dielektriniai.pdf';

    $stmt = $conn->prepare("UPDATE gaminiai SET mt_dielektriniu_pdf = :pdf, mt_dielektriniu_failas = :failas WHERE id = :id");
    $stmt->bindParam('pdf', $pdf_content, PDO::PARAM_LOB);
    $stmt->bindParam('failas', $failo_pavadinimas);
    $stmt->bindParam('id', $gaminio_id);
    $stmt->execute();

    $gaminio_numeris = $_POST['gaminio_numeris'] ?? '';
    $params = http_build_query([
        'gaminys_id' => $gaminio_id,
        'gaminio_numeris' => $gaminio_numeris,
        'uzsakymo_numeris' => $uzsakymo_numeris,
        'uzsakovas' => $uzsakovas,
        'gaminio_pavadinimas' => $gaminio_pavadinimas,
        'uzsakymo_id' => $uzsakymo_id,
        'grupe' => $grupe,
        'pdf_sukurtas' => 'taip'
    ]);
    header("Location: /MT/mt_dielektriniai.php?$params");
    exit;

} catch (\Exception $e) {
    $gaminio_numeris = $_POST['gaminio_numeris'] ?? '';
    $params = http_build_query([
        'gaminys_id' => $gaminio_id,
        'gaminio_numeris' => $gaminio_numeris,
        'uzsakymo_numeris' => $uzsakymo_numeris,
        'uzsakovas' => $uzsakovas,
        'gaminio_pavadinimas' => $gaminio_pavadinimas,
        'uzsakymo_id' => $uzsakymo_id,
        'grupe' => $grupe,
        'pdf_klaida' => $e->getMessage()
    ]);
    header("Location: /MT/mt_dielektriniai.php?$params");
    exit;
}
