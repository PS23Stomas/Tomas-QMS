<?php
/**
 * Slaptažodžio keitimo puslapis - naujo slaptažodžio nustatymas per atstatymo žetoną
 *
 * Šis puslapis leidžia vartotojui nustatyti naują slaptažodį naudojant
 * atstatymo žetoną, gautą el. paštu iš slaptažodžio atstatymo puslapio.
 */

// Sesijos konfigūracija su saugumo parametrais
session_set_cookie_params([
    'lifetime' => 28800, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'None'
]);
ini_set('session.gc_maxlifetime', 28800);
session_start();

require __DIR__ . '/klases/Database.php';
$pdo = Database::getConnection();

// CSRF žetono generavimas (analogiškas config.php csrfToken() funkcijai)
if (empty($_SESSION['_csrf_token'])) {
    $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
}
$_csrf_token = $_SESSION['_csrf_token'];

$pranesimas = '';
$klaida = '';
$token = $_GET['token'] ?? $_POST['token'] ?? '';
$galiojantis = false;

// Žetono tikrinimas ir galiojimo laiko patikra
if (empty($token)) {
    $klaida = 'Netinkama arba trūkstama atstatymo nuoroda.';
} else {
    // Tikrinama ar žetonas galioja (nepasibaigęs galiojimo laikas)
    $stmt = $pdo->prepare("SELECT id, vardas, pavarde FROM vartotojai WHERE login_token = ? AND token_galiojimas > NOW()");
    $stmt->execute([$token]);
    $vartotojas = $stmt->fetch();

    if ($vartotojas) {
        $galiojantis = true;
    } else {
        // Tikrinama ar žetonas egzistuoja, bet jau pasibaigęs
        $stmt2 = $pdo->prepare("SELECT id FROM vartotojai WHERE login_token = ?");
        $stmt2->execute([$token]);
        if ($stmt2->fetch()) {
            $klaida = 'Atstatymo nuoroda nebegalioja. Prašome sukurti naują užklausą.';
        } else {
            $klaida = 'Netinkama atstatymo nuoroda.';
        }
    }
}

// Naujo slaptažodžio išsaugojimas
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $galiojantis) {
    $pateiktas_csrf = $_POST['_csrf'] ?? '';
    if (!$_csrf_token || !hash_equals($_csrf_token, $pateiktas_csrf)) {
        http_response_code(403);
        die('CSRF patikrinimas nepavyko. Atnaujinkite puslapį ir bandykite dar kartą.');
    }
    $naujas = $_POST['slaptazodis'] ?? '';
    $pakartoti = $_POST['slaptazodis2'] ?? '';

    // Slaptažodžio validacija (ilgis ir sutapimas)
    if (empty($naujas)) {
        $klaida = 'Įveskite naują slaptažodį.';
    } elseif (mb_strlen($naujas) < 8) {
        $klaida = 'Slaptažodis turi būti bent 8 simbolių.';
    } elseif (!preg_match('/[0-9]/', $naujas)) {
        $klaida = 'Slaptažodis turi turėti bent vieną skaičių.';
    } elseif ($naujas !== $pakartoti) {
        $klaida = 'Slaptažodžiai nesutampa.';
    } else {
        // Slaptažodžio maišos (hash) kūrimas ir išsaugojimas, žetono pašalinimas
        $hash = password_hash($naujas, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE vartotojai SET slaptazodis = ?, login_token = NULL, token_galiojimas = NULL WHERE id = ?");
        $stmt->execute([$hash, $vartotojas['id']]);

        $pranesimas = 'Slaptažodis sėkmingai pakeistas! Galite prisijungti su nauju slaptažodžiu.';
        $galiojantis = false;
    }
}
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#4c596d">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <title>Naujas slaptažodis - MT Modulis</title>
    <link rel="shortcut icon" type="image/png" href="/favicon-32.png?v=2">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32.png?v=2">
    <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"></noscript>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #a59a6d 0%, #595029 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        .reset-card {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 2.5rem;
            width: 100%;
            max-width: 440px;
        }
        .reset-card h2 {
            font-weight: 700;
            color: #333;
            margin-bottom: 0.5rem;
            text-align: center;
            font-size: 1.5rem;
        }
        .reset-subtitle {
            text-align: center;
            color: #888;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
            line-height: 1.5;
        }
        .form-group { margin-bottom: 1rem; }
        .form-label {
            display: block;
            font-weight: 600;
            color: #555;
            font-size: 0.9rem;
            margin-bottom: 0.4rem;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            font-size: 1rem;
            border: 2px solid #e0e0e0;
            border-radius: 0.5rem;
            font-family: 'Inter', sans-serif;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .form-control:focus {
            outline: none;
            border-color: #736a48;
            box-shadow: 0 0 0 3px rgba(115, 106, 72, 0.2);
        }
        .btn-save {
            width: 100%;
            padding: 0.85rem;
            font-size: 1.05rem;
            font-weight: 600;
            border: none;
            border-radius: 0.5rem;
            background: linear-gradient(135deg, #a59a6d 0%, #595029 100%);
            color: white;
            cursor: pointer;
            transition: opacity 0.2s, transform 0.1s;
            font-family: 'Inter', sans-serif;
            margin-top: 0.5rem;
        }
        .btn-save:hover { opacity: 0.9; }
        .btn-save:active { transform: scale(0.98); }
        .alert {
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            line-height: 1.4;
        }
        .alert-danger { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .back-link {
            text-align: center;
            margin-top: 1.25rem;
        }
        .back-link a {
            color: #a59a6d;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
        }
        .back-link a:hover { text-decoration: underline; }
        .icon-key {
            text-align: center;
            margin-bottom: 1rem;
        }
        .icon-key svg {
            width: 48px;
            height: 48px;
            color: #a59a6d;
        }
        .user-info {
            text-align: center;
            margin-bottom: 1rem;
            padding: 0.75rem;
            background: #f0f0ff;
            border-radius: 0.5rem;
            font-size: 0.9rem;
            color: #555;
        }
        .user-info strong { color: #333; }
        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 0.4rem;
            transition: all 0.3s;
            background: #e0e0e0;
        }
        .password-strength.weak { background: #ef4444; width: 33%; }
        .password-strength.medium { background: #f59e0b; width: 66%; }
        .password-strength.strong { background: #22c55e; width: 100%; }
        @media (max-width: 480px) {
            .reset-card { padding: 1.5rem; }
        }
    </style>
</head>
<body>
    <div class="reset-card">
        <div class="icon-key">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" />
            </svg>
        </div>
        <h2>Naujas slaptažodis</h2>

        <?php if ($klaida): ?>
            <div class="alert alert-danger" data-testid="text-change-error"><?= htmlspecialchars($klaida) ?></div>
        <?php endif; ?>
        <?php if ($pranesimas): ?>
            <div class="alert alert-success" data-testid="text-change-success"><?= htmlspecialchars($pranesimas) ?></div>
        <?php endif; ?>

        <?php if ($galiojantis && $vartotojas): ?>
            <div class="user-info">
                Keičiamas slaptažodis: <strong><?= htmlspecialchars($vartotojas['vardas'] . ' ' . $vartotojas['pavarde']) ?></strong>
            </div>
            <form method="POST" action="/slaptazodis_keitimas.php">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                <input type="hidden" name="_csrf" value="<?= htmlspecialchars($_csrf_token) ?>">
                <div class="form-group">
                    <label class="form-label" for="slaptazodis">Naujas slaptažodis</label>
                    <input type="password" class="form-control" id="slaptazodis" name="slaptazodis" 
                           required autofocus minlength="8"
                           data-testid="input-new-password">
                    <div class="password-strength" id="strengthBar"></div>
                    <small id="slaptazodis_hint" style="display:block; color:#6b7280; font-size:0.82rem; margin-top:4px;" data-testid="text-new-password-hint">Bent 8 simboliai ir vienas skaičius</small>
                    <div id="slaptazodis_error" style="display:none; color:#991b1b; font-size:0.82rem; margin-top:4px;" data-testid="text-new-password-error"></div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="slaptazodis2">Pakartokite slaptažodį</label>
                    <input type="password" class="form-control" id="slaptazodis2" name="slaptazodis2" 
                           required minlength="8"
                           data-testid="input-confirm-password">
                    <div id="slaptazodis2_hint" style="display:none; font-size:0.82rem; margin-top:4px;" data-testid="text-confirm-password-hint"></div>
                </div>
                <button type="submit" class="btn-save" data-testid="button-save-password">Išsaugoti slaptažodį</button>
            </form>
        <?php endif; ?>

        <div class="back-link">
            <?php if ($pranesimas): ?>
                <a href="/login.php" data-testid="link-go-login">Eiti į prisijungimą</a>
            <?php else: ?>
                <a href="/slaptazodis_atstatymas.php" data-testid="link-new-request">Sukurti naują užklausą</a>
                &nbsp;&middot;&nbsp;
                <a href="/login.php" data-testid="link-back-login">Prisijungti</a>
            <?php endif; ?>
        </div>
    </div>

    <script>
    (function() {
        var pw = document.getElementById('slaptazodis');
        var bar = document.getElementById('strengthBar');
        var errorDiv = document.getElementById('slaptazodis_error');
        var hintEl = document.getElementById('slaptazodis_hint');
        var pw2 = document.getElementById('slaptazodis2');
        var hint2 = document.getElementById('slaptazodis2_hint');
        if (!pw) return;

        function validatePw() {
            var v = pw.value;
            if (v.length === 0) {
                if (errorDiv) errorDiv.style.display = 'none';
                if (hintEl) hintEl.style.color = '#6b7280';
                return true;
            }
            if (v.length < 8) {
                if (errorDiv) { errorDiv.textContent = 'Slaptažodis turi būti bent 8 simbolių.'; errorDiv.style.display = 'block'; }
                if (hintEl) hintEl.style.color = '#dc2626';
                return false;
            }
            if (!/[0-9]/.test(v)) {
                if (errorDiv) { errorDiv.textContent = 'Slaptažodis turi turėti bent vieną skaičių.'; errorDiv.style.display = 'block'; }
                if (hintEl) hintEl.style.color = '#dc2626';
                return false;
            }
            if (errorDiv) errorDiv.style.display = 'none';
            if (hintEl) hintEl.style.color = '#16a34a';
            return true;
        }

        function validateConfirm() {
            if (!pw2 || !hint2) return true;
            var val = pw2.value;
            if (val.length === 0) {
                hint2.style.display = 'none';
                return true;
            }
            if (val !== pw.value) {
                hint2.textContent = 'Slaptažodžiai nesutampa.';
                hint2.style.color = '#991b1b';
                hint2.style.display = 'block';
                return false;
            }
            hint2.textContent = 'Slaptažodžiai sutampa.';
            hint2.style.color = '#16a34a';
            hint2.style.display = 'block';
            return true;
        }

        pw.addEventListener('input', function() {
            validatePw();
            if (pw2 && pw2.value.length > 0) validateConfirm();
            if (bar) {
                var v = pw.value;
                var score = 0;
                if (v.length >= 8) score++;
                if (v.length >= 12) score++;
                if (/[A-Z]/.test(v) && /[a-z]/.test(v)) score++;
                if (/[0-9]/.test(v)) score++;
                if (/[^A-Za-z0-9]/.test(v)) score++;
                bar.className = 'password-strength';
                if (score <= 1) bar.classList.add('weak');
                else if (score <= 3) bar.classList.add('medium');
                else bar.classList.add('strong');
            }
        });

        pw2 && pw2.addEventListener('input', validateConfirm);

        pw.closest('form').addEventListener('submit', function(e) {
            if (!validatePw() || !validateConfirm()) e.preventDefault();
        });
    })();
    </script>
</body>
</html>
